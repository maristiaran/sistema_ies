// import 'package:either_dart/either.dart';
// import 'package:sistema_ies/shared/utils/responses.dart';

class RepositoryPort {
  // Future<Either<Failure, Success>> initRepositoryCaches() async {
  //   return Right(Success('ok'));
  // }
}
